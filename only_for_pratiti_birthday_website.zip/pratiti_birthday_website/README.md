# Only for Pratiti 🎀

A mobile-first birthday website made by Mann.

## Run locally
1. Install Node.js.
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm start`
5. Open http://localhost:3000

## Deploy on Render
1. Create a GitHub repository and upload the contents of this folder.
2. In Render, choose **New + → Web Service** and connect the repository.
3. Render detects `render.yaml`; use `npm install` as build command and `npm start` as start command.
4. Add environment variables:
   - `ENTRY_KEY` = `rajeevbkl`
   - `SECRET_KEY` = `rajeevbkl` (temporary second-door key; change it if you want a different one)
   - `SESSION_SECRET` = a long random value
   - `NODE_ENV` = `production`
5. Deploy.

## Important
The music is a tiny original ambient melody generated in the browser with Web Audio. Browsers require a tap before audio can start, so use the Music button after opening the site.

No photos are included yet. The birthday age/date screen is set to 19 November 2010 as provided.

For a real private gift, change both passcodes to something only Pratiti knows. The app checks passcodes on the server and keeps unlock state in a session cookie.
