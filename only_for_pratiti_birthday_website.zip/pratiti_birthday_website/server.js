const express = require("express");
const session = require("express-session");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Set these in Render's Environment settings before publishing.
const ENTRY_KEY = process.env.ENTRY_KEY || "rajeevbkl";
const SECRET_KEY = process.env.SECRET_KEY || "rajeevbkl";
const SESSION_SECRET = process.env.SESSION_SECRET || "change-this-session-secret";

app.use(express.json());
app.use(session({
  name: "pratiti.sid",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

app.post("/api/unlock", (req, res) => {
  const { stage, passcode } = req.body || {};
  const expected = stage === "entry" ? ENTRY_KEY : stage === "secret" ? SECRET_KEY : null;
  if (!expected) return res.status(400).json({ ok: false, message: "Unknown door." });
  if (String(passcode || "").trim().toLowerCase() !== expected.toLowerCase()) {
    return res.status(401).json({ ok: false, message: "Not quite, birthday girl. Try again 💗" });
  }
  if (stage === "entry") req.session.entryUnlocked = true;
  if (stage === "secret" && req.session.entryUnlocked) req.session.secretUnlocked = true;
  if (stage === "secret" && !req.session.entryUnlocked) {
    return res.status(403).json({ ok: false, message: "Open the first door first." });
  }
  return res.json({ ok: true, message: "Access granted ✨" });
});

app.get("/api/status", (req, res) => {
  res.json({
    entryUnlocked: !!req.session.entryUnlocked,
    secretUnlocked: !!req.session.secretUnlocked
  });
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Pratiti's birthday world is running on ${PORT}`));
